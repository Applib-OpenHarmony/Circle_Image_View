/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../DevEcoStudioProjects/ImageCircle/LibCircle/circleImage.ets":
/*!******************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/ImageCircle/LibCircle/circleImage.ets ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RoundImage = void 0;
class RoundImage extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.__imageWidth = new SynchedPropertySimpleTwoWay(params.imageWidth, this, "imageWidth");
        this.__imageHeight = new SynchedPropertySimpleTwoWay(params.imageHeight, this, "imageHeight");
        this.__borderRadius = new SynchedPropertySimpleTwoWay(params.borderRadius, this, "borderRadius");
        this.__borderWidth = new SynchedPropertySimpleTwoWay(params.borderWidth, this, "borderWidth");
        this.__borderColor = new SynchedPropertySimpleTwoWay(params.borderColor, this, "borderColor");
        this.__objectFit = new SynchedPropertySimpleTwoWay(params.objectFit, this, "objectFit");
        this.__imageSource = new SynchedPropertySimpleTwoWay(params.imageSource, this, "imageSource");
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.context1 = new CanvasRenderingContext2D(this.settings);
        this.img = undefined;
        this.img1 = undefined;
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.context1 !== undefined) {
            this.context1 = params.context1;
        }
        if (params.img !== undefined) {
            this.img = params.img;
        }
        if (params.img1 !== undefined) {
            this.img1 = params.img1;
        }
    }
    aboutToBeDeleted() {
        this.__imageWidth.aboutToBeDeleted();
        this.__imageHeight.aboutToBeDeleted();
        this.__borderRadius.aboutToBeDeleted();
        this.__borderWidth.aboutToBeDeleted();
        this.__borderColor.aboutToBeDeleted();
        this.__objectFit.aboutToBeDeleted();
        this.__imageSource.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get imageWidth() {
        return this.__imageWidth.get();
    }
    set imageWidth(newValue) {
        this.__imageWidth.set(newValue);
    }
    get imageHeight() {
        return this.__imageHeight.get();
    }
    set imageHeight(newValue) {
        this.__imageHeight.set(newValue);
    }
    get borderRadius() {
        return this.__borderRadius.get();
    }
    set borderRadius(newValue) {
        this.__borderRadius.set(newValue);
    }
    get borderWidth() {
        return this.__borderWidth.get();
    }
    set borderWidth(newValue) {
        this.__borderWidth.set(newValue);
    }
    get borderColor() {
        return this.__borderColor.get();
    }
    set borderColor(newValue) {
        this.__borderColor.set(newValue);
    }
    get objectFit() {
        return this.__objectFit.get();
    }
    set objectFit(newValue) {
        this.__objectFit.set(newValue);
    }
    get imageSource() {
        return this.__imageSource.get();
    }
    set imageSource(newValue) {
        this.__imageSource.set(newValue);
    }
    render() {
        Row.create();
        Row.debugLine("../../../../../LibCircle/circleImage.ets(18:5)");
        Column.create();
        Column.debugLine("../../../../../LibCircle/circleImage.ets(19:7)");
        Flex.create({
            direction: FlexDirection.Column,
            alignItems: ItemAlign.Center,
            justifyContent: FlexAlign.Center
        });
        Flex.debugLine("../../../../../LibCircle/circleImage.ets(20:9)");
        Canvas.create(this.context1);
        Canvas.debugLine("../../../../../LibCircle/circleImage.ets(25:11)");
        Canvas.width('100%');
        Canvas.height('45%');
        Canvas.backgroundColor(Color.White);
        Canvas.onReady(() => {
            this.img1 = new ImageBitmap(this.imageSource);
            this.context1.imageSmoothingEnabled = false;
            //              var r = { x: 0, y: 0, w: this.imageWidth, h: this.imageHeight };
            this.context1.save();
            this.context1.beginPath();
            //              this.context.moveTo(r.x + r.w, r.y + 0.5 * r.h);
            //              this.context.bezierCurveTo(r.x + r.w, r.y + 0.25 * r.h, r.x + 0.75 * r.w, r.y, r.x + 0.5 * r.w, r.y);
            this.context1.arc(180, 180, 100, 0, Math.PI * 2, false);
            this.context1.strokeStyle = "#0a0a0a";
            this.context1.lineWidth = 10;
            this.context1.stroke();
            //              this.context.bezierCurveTo(r.x + 0.25 * r.w, r.y, r.x, r.y + 0.25 * r.h, r.x, r.y + 0.5 * r.h);
            //              this.context.bezierCurveTo(r.x, r.y + 0.75 * r.h, r.x + 0.25 * r.w, r.y + r.h, r.x + 0.5 * r.w, r.y + r.h);
            //              this.context.bezierCurveTo(r.x + 0.75 * r.w, r.y + r.h, r.x + r.w, r.y + 0.75 * r.h, r.x + r.w, r.y + 0.5 * r.h);
            //              this.context.closePath();
            this.context1.clip();
            //              this.context.drawImage(this.img, r.x, r.y, r.w, r.h);
            this.context1.drawImage(this.img1, 0, 0, 360, 360);
            //        this.context.drawBorder({width: r.w, color: this.borderColor});
            this.context1.restore();
        });
        Canvas.pop();
        Canvas.create(this.context);
        Canvas.debugLine("../../../../../LibCircle/circleImage.ets(51:11)");
        Canvas.width('100%');
        Canvas.height('50%');
        Canvas.backgroundColor(Color.Black);
        Canvas.onReady(() => {
            this.img = new ImageBitmap(this.imageSource);
            this.context.imageSmoothingEnabled = false;
            //              var rr = { x: 0, y: 0, w: this.imageWidth, h: this.imageHeight };
            this.context.save();
            this.context.beginPath();
            //              this.context.moveTo(rr.x + rr.w, rr.y + 0.5 * rr.h);
            this.context.arc(180, 180, 100, 0, Math.PI * 2, false);
            this.context.strokeStyle = "#f6f5f7";
            this.context.lineWidth = 5;
            this.context.stroke();
            //              this.context.bezierCurveTo(rr.x + rr.w, rr.y + 0.25 * rr.h, rr.x + 0.75 * rr.w, rr.y, rr.x + 0.5 * rr.w, rr.y);
            //              this.context.bezierCurveTo(rr.x + 0.25 * rr.w, rr.y, rr.x, rr.y + 0.25 * rr.h, rr.x, rr.y + 0.5 * rr.h);
            //              this.context.bezierCurveTo(rr.x, rr.y + 0.75 * rr.h, rr.x + 0.25 * rr.w, rr.y + rr.h, rr.x + 0.5 * rr.w, rr.y + rr.h);
            //              this.context.bezierCurveTo(rr.x + 0.75 * rr.w, rr.y + rr.h, rr.x + rr.w, rr.y + 0.75 * rr.h, rr.x + rr.w, rr.y + 0.5 * rr.h);
            this.context.closePath();
            this.context.clip();
            //              this.context.drawImage(this.img, rr.x, rr.y, rr.w, rr.h);
            this.context.drawImage(this.img, 0, 0, 360, 360);
            //        this.context.drawBorder({width: r.w, color: this.borderColor});
            this.context.restore();
        });
        Canvas.pop();
        Flex.pop();
        Column.pop();
        Row.pop();
    }
}
exports.RoundImage = RoundImage;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		var commonCachedModule = globalThis["__common_module_cache__"] ? globalThis["__common_module_cache__"][moduleId]: null;
/******/ 		if (commonCachedModule) { return commonCachedModule.exports; }
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		if (globalThis["__common_module_cache__"] && moduleId.indexOf("?name=") < 0 && Object.keys(globalThis["__common_module_cache__"]).indexOf(moduleId) >= 0) {
/******/ 		  globalThis["__common_module_cache__"][moduleId] = module;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;
/*!*********************************************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/ImageCircle/entry/src/main/ets/MainAbility/pages/index.ets?entry ***!
  \*********************************************************************************************************************/

Object.defineProperty(exports, "__esModule", ({ value: true }));
const circleImage_1 = __webpack_require__(/*! ../../../../../node_modules/LibCircle/circleImage */ "../../../../../../../../DevEcoStudioProjects/ImageCircle/LibCircle/circleImage.ets");
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.__borderRadius = new ObservedPropertySimple(50, this, "borderRadius");
        this.__borderWidth = new ObservedPropertySimple(1, this, "borderWidth");
        this.__borderColor = new ObservedPropertySimple(Color.Black, this, "borderColor");
        this.__imageWidth = new ObservedPropertySimple(200, this, "imageWidth");
        this.__imageHeight = new ObservedPropertySimple(200, this, "imageHeight");
        this.__objectFit = new ObservedPropertySimple(ImageFit.Contain, this, "objectFit");
        this.__imageSource = new ObservedPropertySimple('/common/images/user.png', this, "imageSource");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.borderRadius !== undefined) {
            this.borderRadius = params.borderRadius;
        }
        if (params.borderWidth !== undefined) {
            this.borderWidth = params.borderWidth;
        }
        if (params.borderColor !== undefined) {
            this.borderColor = params.borderColor;
        }
        if (params.imageWidth !== undefined) {
            this.imageWidth = params.imageWidth;
        }
        if (params.imageHeight !== undefined) {
            this.imageHeight = params.imageHeight;
        }
        if (params.objectFit !== undefined) {
            this.objectFit = params.objectFit;
        }
        if (params.imageSource !== undefined) {
            this.imageSource = params.imageSource;
        }
    }
    aboutToBeDeleted() {
        this.__borderRadius.aboutToBeDeleted();
        this.__borderWidth.aboutToBeDeleted();
        this.__borderColor.aboutToBeDeleted();
        this.__imageWidth.aboutToBeDeleted();
        this.__imageHeight.aboutToBeDeleted();
        this.__objectFit.aboutToBeDeleted();
        this.__imageSource.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get borderRadius() {
        return this.__borderRadius.get();
    }
    set borderRadius(newValue) {
        this.__borderRadius.set(newValue);
    }
    get borderWidth() {
        return this.__borderWidth.get();
    }
    set borderWidth(newValue) {
        this.__borderWidth.set(newValue);
    }
    get borderColor() {
        return this.__borderColor.get();
    }
    set borderColor(newValue) {
        this.__borderColor.set(newValue);
    }
    get imageWidth() {
        return this.__imageWidth.get();
    }
    set imageWidth(newValue) {
        this.__imageWidth.set(newValue);
    }
    get imageHeight() {
        return this.__imageHeight.get();
    }
    set imageHeight(newValue) {
        this.__imageHeight.set(newValue);
    }
    get objectFit() {
        return this.__objectFit.get();
    }
    set objectFit(newValue) {
        this.__objectFit.set(newValue);
    }
    get imageSource() {
        return this.__imageSource.get();
    }
    set imageSource(newValue) {
        this.__imageSource.set(newValue);
    }
    render() {
        Row.create();
        Row.debugLine("pages/index.ets(13:5)");
        Row.height('100%');
        Column.create();
        Column.debugLine("pages/index.ets(14:7)");
        Column.width('100%');
        Text.create('CircleImageViewSample');
        Text.debugLine("pages/index.ets(15:9)");
        Text.fontSize(25);
        Text.lineHeight(25);
        Text.border({ width: 1 });
        Text.padding(5);
        Text.width('100%');
        Text.backgroundColor(Color.Black);
        Text.fontColor(Color.White);
        Text.pop();
        let earlierCreatedChild_2 = this.findChildById("2");
        if (earlierCreatedChild_2 == undefined) {
            View.create(new circleImage_1.RoundImage("2", this, {
                borderRadius: this.__borderRadius,
                borderWidth: this.__borderWidth,
                borderColor: this.__borderColor,
                imageWidth: this.__imageWidth,
                imageHeight: this.__imageHeight,
                objectFit: this.__objectFit,
                imageSource: this.__imageSource
            }));
        }
        else {
            earlierCreatedChild_2.updateWithValueParams({});
            View.create(earlierCreatedChild_2);
        }
        let earlierCreatedChild_3 = this.findChildById("3");
        if (earlierCreatedChild_3 == undefined) {
            View.create(new circleImage_1.RoundImage("3", this, {
                borderRadius: this.__borderRadius,
                borderWidth: this.__borderWidth,
                borderColor: this.__borderColor,
                imageWidth: this.__imageWidth,
                imageHeight: this.__imageHeight,
                objectFit: this.__objectFit,
                imageSource: this.__imageSource
            }));
        }
        else {
            earlierCreatedChild_3.updateWithValueParams({});
            View.create(earlierCreatedChild_3);
        }
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Index("1", undefined, {}));

})();

/******/ })()
;
//# sourceMappingURL=index.js.map