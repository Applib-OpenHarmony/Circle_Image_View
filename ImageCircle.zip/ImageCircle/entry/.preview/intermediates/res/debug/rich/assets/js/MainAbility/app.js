/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;
/*!*************************************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/ImageCircle/entry/src/main/ets/MainAbility/app.ets?entry ***!
  \*************************************************************************************************************/

Object.defineProperty(exports, "__esModule", ({ value: true }));
globalThis.exports.default = {
    onCreate() {
        console.info('Application onCreate');
    },
    onDestroy() {
        console.info('Application onDestroy');
    },
};

})();

/******/ })()
;
//# sourceMappingURL=app.js.map